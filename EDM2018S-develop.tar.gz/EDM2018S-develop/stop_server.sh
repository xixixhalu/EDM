forever stopall
