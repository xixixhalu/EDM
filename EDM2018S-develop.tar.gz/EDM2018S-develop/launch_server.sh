#forever start -a -l /home/rootedm/EDMToolkit/static/js/serverLog.txt ./static/js/Server.js
#forever start -a -l /home/ubuntu/EDMToolKit/static/js/serverLog.txt ./static/js/Server.js
forever start -a -l /home/ubuntu/EDMToolKit/generated_code/serverLog.txt ./generated_code/default/generalization/Server.js
