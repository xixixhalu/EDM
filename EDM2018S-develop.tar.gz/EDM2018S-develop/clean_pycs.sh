find . -name "*.pyc" -exec rm -rf {} \;
