$FUNC $method
$model.$method = function($parameters) {
    // Define data operation logic

    // Wrap data

    // Define callback function
    function successCB(msg) {
        // Success handling
    }

    function errorCB(msg) {
        // Error handling
    }

    // Call RESTful API via DBAdapter

};
$ENDFUNC
